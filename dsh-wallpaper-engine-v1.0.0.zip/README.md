# dsh-skin-wallpaper-engine

把本机 **Wallpaper Engine** 的**视频类**动态壁纸接进 DSH 对话页当背景，左下角浮动面板可搜索、切换、调不透明度/模糊/压暗，并把**左侧栏和对话输入框做成毛玻璃**。

## 为什么只支持 video 类

| `project.json` 的 `type` | 浏览器能播吗 | 说明 |
|--------------------------|--------------|------|
| `video`（.mp4 / .webm） | ✅ | 本插件支持 |
| `picture` | ✅ | 静态图，本机当前没有 |
| `scene`（.pkg） | ❌ | 专有格式，必须由 Wallpaper Engine 本体渲染 |
| `application` | ❌ | 外部程序渲染 |
| `web` | △ | 需要 iframe，未实现 |

另外 `.mkv` / `.mov` **故意排除**：Edge 播不了，列出来只会给用户一个黑屏。

## 架构

浏览器读不了本地文件，所以拆两侧：

- **宿主侧 `lib/index.js`**（`inject: ["webServer"]`）注册三条路由：
  - `GET /wallpaper-engine/list` —— 扫描壁纸目录，返回可播放清单
  - `GET /wallpaper-engine/media/<id>` —— 下发媒体文件，支持 `Range`
  - `GET /wallpaper-engine/preview/<id>` —— 下发该壁纸自带的 `preview.jpg`（网格缩略图用），带 `max-age=3600` 缓存
  - `<id>` 是绝对路径的 base64url；**每次请求都重新校验**它解析后位于允许的根目录内且扩展名合法，伪造 id 读不到别的文件。
- **浏览器侧 `lib/client.js`**：背景层 + 浮动面板 + `localStorage` 记忆。

## ⚠️ 两个必须记住的坑（都踩过）

### 1. `__ModuleLoader__.load({ id })` 必须等于**包名**

```js
window.__ModuleLoader__.load({
  id: "dsh-skin-wallpaper-engine",   // 必须是包名，不能随便起
```

写错会得到：

```
client-modules: bundle /plugins/??... loaded without registering "..." via __ModuleLoader__.load
```

后果是**整棵插件树加载失败**，DSH 界面变成一个报错页 —— 用户会以为"DSH 坏了"。

### 2. `cordis.patch.yml` 里的行 **id 不能以 `ui-skin-` 开头**

DSH 的皮肤管理器托管的就是 `ui-skin-*` 行。用这个前缀会被当成第三款皮肤并触发互斥，**把用户当前启用的皮肤挤掉**。本插件用 `wallpaper-engine-bg`。

## 安全模型（v2）

v1 会在视频播不出来时把界面变成一片黑。现在：

1. **只有视频真正触发 `playing` 才设置 `data-dsh-wallpaper-engine`** —— 404 / 编解码不支持 / 一直不出画面，UI 保持**完全原样**。
2. **4 秒看门狗**：没等到 `playing` 就自动关闭背景，并清掉记住的选择。
3. 背景层放在 `z-index:-1`，**从不重排应用自身的 DOM**（v1 给每个 body 子元素设过 `position/z-index`，会破坏 DSH 的浮层）。
4. 高于基础表面的层保持近不透明（86% / overlay 96%），弹层和菜单对比度不受影响。
5. **逃生开关**：启动时 URL 加 `#no-wallpaper=1`，或任何时候按 **Shift+W**；
   毛玻璃太吃 GPU 时可以 `#no-glass=1` 关掉。

## 用法

| 操作 | 效果 |
|------|------|
| 左下角 🖼 | 打开面板（避开右下角的鲸鱼挂件） |
| 点列表项 | **只预览**，不动背景；点「应用这张」才真正切换 |
| 滑杆 | 不透明度 / **亮度** / 模糊 / 压暗 / **侧栏模糊** / **输入框模糊** / **玻璃饱和**，随改随存 |
| 「原视频亮度」按钮 | 一键：压暗 0、亮度 100%、界面不透明 12%，让壁纸尽量还原成原片 |
| 「玻璃拟态」勾选框 | 左侧栏 + 输入框的毛玻璃开关（下面重复了一行，见表格上文） |
| 「玻璃拟态」勾选框 | 左侧栏 + 输入框的毛玻璃开关 |
| 随机一个 / 关闭背景 | 见名（随机只是选中预览，仍要点「应用这张」）|
| `#wallpaper-panel=1\|2\|3` | 直接打开面板并跳到 壁纸 / 外观 / 高级 页 |
| `#wallpaper=<序号或标题片段>` | 深度链接，直接应用某个壁纸 |

> **参数要写在 `#` 后面，不能写 `?`。** DSH 服务端对带查询串的地址直接 `303 → /`，
> 连 token 一起抹掉，所以 `?wallpaper=0` 这类参数**根本到不了浏览器**（这是实测出来的：
> 皮肤里读 `window.location.search` 永远是空的）。`location.hash` 不发给服务器、
> 重定向时浏览器也会保留，所以自定义参数一律走 `#`。

## 壁纸根目录

写死在 `lib/index.js` 的 `ROOTS`：

```
D:\Steam\steamapps\common\wallpaper_engine\projects
D:\Steam\steamapps\workshop\content\431960
```

## 安装

```
dsh plugin --profile web add link:F:\DeepSeek\wallpaper-engine-skin
```

或手动：拷进 `%DSH_HOME%\profiles\web\node_modules\`，并在该 profile 的 `package.json` 里
加入 `dependencies` 与 `dsh.profile.bundles`（两处都要）。装完重启 DSH。

## 开发/验证方式

`F:\DeepSeek\.we-test\` 是隔离测试环境：一个独立的 `DSH_HOME`（不碰 `~/.dsh`），
用 `DSH_HOME=F:\DeepSeek\.we-test node <dsh>/lib/bin.js web --no-open --port 3099` 启动，
再用 headless Edge 截图验证：

```
msedge --headless=new --disable-gpu --user-data-dir=<tmp> --screenshot=out.png "<url>"
```

注意两点：

- 不要加 `--virtual-time-budget` —— DSH 的 SSE 长连接会让页面永不空闲，截图永远不触发。
- 要加 `--timeout=6000`：壁纸是异步 fetch 之后才创建的，默认截图时机太早，
  拍到的是一张没有壁纸（因此也没有毛玻璃）的画面。

## v3 变更

- **画质**：只有 `blur > 0` 时才加 `filter` 与 `transform: scale(1.04)`；模糊为 0 时画面保持 1:1，
  不再无谓重采样。`scale(1.04)` 原本是为了遮模糊边缘，常驻反而让画面变软。
- **默认值**：界面不透明 78% → **60%**，压暗 25% → **15%**。原来是"界面优先"，壁纸只剩约 16% 可见度，
  看起来发灰发平。现在默认更偏壁纸；嫌界面看不清就把「界面不透明」拉高。
- **按钮可拖动**：按住 🖼 拖到任意位置（比如右上角偏下），位置按**视口比例**记住，换分辨率也不会跑飞。
  面板会判断按钮在屏幕上半/下半，自动向上或向下展开并夹在视口内。面板里新增「重置按钮位置」。

> 画质的主观上限还受两点限制：壁纸本身的码率，以及 4K 源在窗口里必然要降采样。

## v4 变更：毛玻璃（glassmorphism）

把**左侧栏**和**对话输入框**做成 macOS vibrancy 那种半透明磨砂面。

### 为什么原来透不过来

这两个区域各有自己的填充变量，而皮肤原来只覆盖 `--dsw-alias-bg-*`，管不到它们，
所以它们一直是不透明的：

| 区域 | 原本的背景 |
|------|-----------|
| 左侧栏 | `.hHd-Xa_root` / `.pI_x6G_sidebarCol` 用 `var(--dsw-specific-sidebar-fill)` |
| 输入框 | `.uV2eYG_card` 用 `var(--dsw-specific-input-major)` + `box-shadow: var(--dsw-elevation-soft)` |

修法是**把这两个区域的填充变量本身换成半透明版**，而不是逐个元素改背景：

```css
/* body 上先把原色抄一份，避免自我引用 */
body[data-dsh-wallpaper-engine][data-dsh-we-glass]{
  --dsh-we-side-fill: var(--dsw-specific-sidebar-fill, #f9fafb);
}
/* 在区域内换成半透明，区域里所有引用它的地方一起变透明 */
div:has(> [data-slot="sidebar"]){
  --dsw-specific-sidebar-fill: color-mix(in srgb, var(--dsh-we-side-fill) var(--dsh-we-alpha,60%), transparent);
  --dsw-alias-button-elevated-fill: color-mix(in srgb, var(--dsh-we-side-fill) var(--dsh-we-alpha2,72%), transparent);
}
```

这样能自动覆盖那些"藏在别处的同色补丁"。踩过的两个：

| 症状 | 元凶 |
|------|------|
| 侧边栏下方有一条不透明色带 | `.bhn1Oq_fade` —— 会话列表底部的渐隐遮罩，`background: linear-gradient(transparent, var(--dsw-specific-sidebar-fill))`，用的是不透明原色 |
| 「新会话」按钮还是纯白 | `.hHd-Xa_newSession` 用 `var(--dsw-alias-button-elevated-fill)`（浅色主题下是 `#fff`） |

再补 `backdrop-filter: blur() saturate(1.8)`、一条发丝边框和一道内高光。
侧栏和输入框的模糊半径是**两个独立变量**（`--dsh-we-glass-side` / `--dsh-we-glass-input`），
面板上对应两个滑杆。

### 选择器用 DSH 自己的扩展点，不用哈希类名

DSH 前端给关键区域挂了语义属性，比 `_boot_1fywu_3` 这种带构建哈希的类名稳得多
（重建前端也不会失效）：

- `[data-slot="sidebar"]` —— 注意它本身是 `display:contents`，真正的盒子是它的子元素
- `[data-composer-card="true"]` —— 就是那个圆角输入框卡片
- 左侧栏的列用 `div:has(> [data-slot="sidebar"])` 选中
- 其它可用插槽：`root` / `main` / `main.conversation` / `rightbar` / `shell.overlay` /
  `sidebar.workspaces` / `sidebar.footer.action` / `sidebar.settings` / `conversation.composer.bar` …

### 安全约束

所有玻璃规则都挂在 `body[data-dsh-wallpaper-engine]` 下面，而那个属性**只在视频真的
`playing` 之后**才设置。所以壁纸没播起来时这两个区域保持原样，
不会出现「半透明了却没东西可透」的破相。

### 踩坑：整套界面填充色都退到了深色兜底值

皮肤的界面填充色原本写成：

```css
html{ --dsh-we-base: var(--dsw-alias-bg-base, #10141a); }
```

但**主题把 `--dsw-alias-bg-base` 定义在 `body` 上**（浅色 `#fff` / 深色 `#151517`），
在 `html` 上读不到 —— 于是这套 alias 全部退到深色兜底值，
**浅色主题下整页也被糊了一层深色 60% 遮罩**，壁纸自然发暗。
现在按主题写死准确的十六进制值（六个 alias 在深浅两套下的真实色都从主题 CSS 里解析过）。

> 实测同一区域：修之前平均亮度 6~11，修之后 27~28，整体提亮约 20 级。

### 踩坑：backdrop-filter 会把「设置」面板卡在侧边栏里

`backdrop-filter`（和 `filter` 一样）会让元素成为 **fixed / absolute 后代的包含块**。
而 DSH 的「设置」面板就渲染在侧边栏内部 —— 一旦把 `backdrop-filter` 加在侧边栏**本体**上，
面板的定位参照就从视口变成了侧边栏那一列，直接展开不出来（实测踩到过）。

正确做法：**用 `position:relative` + `z-index` 造层叠上下文，把模糊画在伪元素上**。

```css
/* 本体：绝不带 backdrop-filter，只造层叠上下文 */
div:has(> [data-slot="sidebar"]){
  position: relative;   /* 只影响 absolute 后代，对 fixed 的面板没影响 */
  z-index: 1000;        /* 必须 ≥ 1000，见下 */
  background: transparent !important;
}
/* 模糊在伪元素上；它待在侧边栏的层叠上下文里 */
div:has(> [data-slot="sidebar"])::before{
  content:""; position:absolute; inset:0; z-index:-1; pointer-events:none;
  backdrop-filter: blur(18px) saturate(var(--dsh-we-glass-sat,.7));
}
```

### 还有第二个坑：`z-index:-1` 会被 frame 的背景埋掉

中间我试过把伪元素写成 `position:fixed` + `z-index:-1`（贴视口左侧，宽度用 JS 同步）。
结果**设置面板正常了，但模糊和饱和度滑杆拖了没反应**。

原因：`z-index:-1` 让伪元素参与**根层叠上下文**的负 z-index 绘制阶段，而那个阶段
早于 `.pI_x6G_frame` 的背景绘制 —— 而 frame 铺满整页、带一层 60% 白色蒙版。于是：

```
视频 → 模糊伪元素 → frame 的 60% 白蒙版 → 侧边栏的文字图标
```
模糊被白蒙版埋住了，肉眼几乎看不出变化。

**所以「造层叠上下文」和「承载模糊」必须分给两个不同的元素**：
本体负责 `position:relative` + `z-index`（造上下文、且不影响 fixed 面板），
伪元素负责 `backdrop-filter`（待在上下文里，画在 frame 背景之上、内容之下）。

实测（同一张图）：侧边栏相邻像素差 **0.03**，紧邻主区域 **0.29** —— 模糊确实生效了。
另外 `inset:0` 让伪元素自动跟随侧边栏尺寸，可折叠宽度也不用 JS 同步了。

### 第三个坑：`z-index` 要 ≥ 1000，否则设置面板被对话内容盖住

给侧边栏加 `position:relative` 会顺手把它变成**层叠上下文**，而设置面板渲染在侧边栏**内部** ——
于是面板的层级被"钉住"了：上下文对外只有多高，面板就只剩多高。

DSH 自己的层级档位（从前端 CSS 里查出来的）：

| z-index | 用途 |
|---------|------|
| 1 / 2 / 3 / 6 | 复制按钮、代码块展开器、分隔线 |
| 10 / 70 | dock 遮罩、菜单 |
| **100 / 101** | 对话气泡、卡片、子菜单 |
| **1000** | **设置弹窗根节点 `._root_w1urq_2`** |
| 1100 | portal、toast、引导遮罩 |

所以侧边栏的 `z-index` 必须 **≥ 1000**：

- 侧边栏**内部**：面板(1000) > 内容(auto) → 弹窗蒙版照常压暗侧边栏内容 ✓
- **根层叠**里：整个上下文(1000) > 对话区(100) → 面板盖得住对话和粘性代码头 ✓

一开始写成 `z-index:1`，结果对话里的粘性代码头（z-index 1~3）和气泡（100）把设置面板盖住了。
**不要改回小数值。**

输入框卡片本来就是 `position:relative`（已经是绝对定位后代的包含块），所以给它加
`isolation:isolate` 后同样把模糊放到 `::before` 上，行为完全不变。

### 踩坑：玻璃区域会偏艳（饱和度）

macOS vibrancy 的惯例是在模糊后面再补一点饱和度提升，我一开始照抄了 `saturate(1.8)`。
但那个提升**只作用在玻璃区域背后的画面上**，而周围区域显示的是未处理的原始视频 ——
结果就是「左侧栏比别处更艳」的色差，肉眼很明显。

反过来查过一轮：主区域和侧边栏的**上色链条完全相同**（都没有额外的白蒙版），
所以剩下的差异来自 `backdrop-filter` 合成本身（Chrome 在合成 backdrop 时的色彩空间处理会让结果偏艳）。
这种残差没法靠"找到元凶"消除，只能反向补偿。

现在 `--dsh-we-glass-sat` 由面板上的「玻璃饱和」滑杆控制（20%~160%，默认 70%）。
觉得还是偏艳就继续往下压；想要 macOS 那种浓郁感就往上拉。

> 注意：这个指标没法用截图精确验证 —— 每张截图都是视频的不同帧，跨图比较无效，
> 同图比较又会被画面内容干扰。所以最终以肉眼为准。

### 排查开关

`#wallpaper-diag=1` 会在页面左下角贴一份运行时状态（壁纸列表数量、video readyState、
body 上的属性、玻璃模糊变量、侧边栏的计算样式……）。面板打不开、或者用无头浏览器排查时非常有用。

---

## v5 变更：居中模态面板 + 壁纸预览

面板从一个贴边的浮动小窗改成了**居中模态**，形状照抄 DSH 自己的设置弹窗
（从它运行时 CSS 里读出来的，不是目测）：

| 部件 | 取值（与 DSH 设置一致）|
|------|------------------------|
| 遮罩 | `var(--dsw-alias-bg-mask-1)` + `backdrop-filter: var(--dsw-mask-blur)` |
| 面板 | `800px` / `max-width: calc(100vw - 48px)` / `height: min(800px, 100vh - 48px)` |
| 圆角 | `32px` |
| 背景 | `var(--dsw-alias-bg-layer-2)` |
| 阴影 | `var(--dsw-elevation-prominent)` |
| 导航列 | 宽 `188px`、`padding: 22px 12px 0`、导航项 `40px` / 圆角 `12px` |
| 头部 | 高 `54px`、`padding: 20px 14px 8px 10px` |
| 内容区 | `padding: 0 24px 24px` |

实测截图：面板恰好 **320..1120**（居中、800 宽），与设置界面一致。
层级用 **1100**（DSH 设置弹窗是 1000、portal/toast 是 1100），点遮罩或按 Esc 关闭。

### 三页结构

- **壁纸**：上方大预览（16:9，约 462×260）+ 标题/大小 + 应用/随机/关闭；下方搜索框 + **三列缩略图网格**
- **外观**：界面不透明、亮度、玻璃拟态开关
- **高级**：模糊、压暗、侧栏模糊、输入框模糊、玻璃饱和 + 原视频亮度 / 重置按钮位置

### 缩略图网格（v5.1）

每格是壁纸**自带的 `preview.jpg`**（实测 98/98 全都有，普遍 800×800~1080×1080），
走 `/wallpaper-engine/preview/<id>` 下发 —— **静态图，零解码开销**，98 张随便滚。
格子是 16:9、源图是方的，所以用 `object-fit: cover` 裁切。

**悬停那一格才播**：鼠标停住约 180ms 才在那一格里插入真正的小视频（只多 1 路解码），
移开立刻 `pause()` + 摘 `src` + `load()` + 移除元素。同一时刻最多只有这一路。
180ms 的延迟是为了避免鼠标快速划过时反复开关解码器。

> 网格布局必须写 `repeat(3, minmax(0, 1fr))`，不能写 `repeat(3, 1fr)`：
> `1fr` 的实际值是 `minmax(auto, 1fr)`，而卡片标题是 `white-space: nowrap`，
> 它的 min-content 宽度会把列撑开，三列直接溢出面板（实测踩到：只剩 1.5 列）。

### 预览的开销（重要）

大预览复用的是 `/wallpaper-engine/media/<id>` 路由（本来就支持 `Range`）。
但这些是 4K 文件，**大预览等于第二路解码** —— 所以只有选中时才挂 `src`，
关闭模态立刻 `pause()` + 摘 `src` + `load()` 把解码器释放掉，不让它常驻。

### 踩坑：主按钮别用品牌令牌，禁用态别用整体 opacity

两个都会造成"按钮全白没字"：

1. `--dsw-alias-brand-primary` 在不同主题下含义不一致 —— 实测会把按钮渲染成**浅色底**，
   而我又写死了 `color:#fff`，于是**白底白字**。现在直接写死 `#1b1b1b` + 白字，
   并用 `body[data-ds-dark-theme]` 反转成浅底深字。
2. 禁用态原来用 `opacity:.5`：深色主按钮 + 白字一起半透明之后，白字同样被冲淡到看不见。
   现在禁用态改成显式的**灰底 + 灰字**，不再动 opacity。

### 拖动滑杆时"窥视"

调参数最烦的是面板挡住壁纸。所以：**按下滑杆 → 面板外框、蒙版、导航、标题、按钮、列表全部隐去，
只留下控制条本体**；松开立刻恢复。

- 控制条**保持原位不动**（不是挪到别处），所以拖动过程中光标不会跑，可以一直拖着看效果
- 留下的控制条有自己的半透明底 + `backdrop-filter`，在壁纸上仍然看得清
- 用 `pointerdown` / `pointerup`（鼠标和触屏都对）；`pointerup` 挂在 `document` 上，
  防止指针拖出滑杆范围后漏掉事件导致面板回不来
- `#wallpaper-peek=1` 可以直接以窥视态打开（调试/验证用）

### 交互

- 单击列表项 = **只预览**，不动背景；点「应用这张」才真正切换（避免看错就切掉了）
- 当前生效那张在列表里带「当前」标记，按钮显示「已是当前壁纸」
- `#wallpaper-panel=1|2|3` 打开面板并直接跳到对应页
