﻿#Requires -Version 5.1
<#
  壁纸引擎插件 · 一键安装
  ========================
  只做几件事，而且改任何配置之前都先备份：

    1. 定位 DSH 主目录（%DSH_HOME%，默认 %USERPROFILE%\.dsh）
    2. 挑一个要装的 profile（默认优先 web）
    3. 把插件拷到 <DSH_HOME>\plugins\dsh-skin-wallpaper-engine
    4. 改该 profile 的 package.json：dependencies + dsh.profile.bundles
    5. 把插件放进该 profile 的 node_modules

  卸载跑 uninstall.ps1（或在资源管理器里双击「卸载.cmd」）。
#>
[CmdletBinding()]
param(
  # 手动指定 DSH 主目录（默认自动找）
  [string]$DshHome,
  # 手动指定 profile 名（默认优先 web）
  [string]$Profile
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$PLUGIN = 'dsh-skin-wallpaper-engine'
$here = $PSScriptRoot

function Remove-Tree($path) {
  <#
    安全删除目录。关键：如果是 junction / 符号链接，只删链接本身。
    Windows PowerShell 5.1 的 Remove-Item -Recurse 会顺着重解析点把【目标】
    里的东西一起删掉 —— 而 DSH 的 link: 装法下那个目标就是插件的源码目录，
    删了就真没了。
  #>
  if (-not (Test-Path -LiteralPath $path)) { return }
  $item = Get-Item -LiteralPath $path -Force
  if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
    try {
      [System.IO.Directory]::Delete($path, $false)
    } catch {
      [void](cmd /c rmdir "$path" 2>&1)
    }
    return
  }
  Remove-Item -LiteralPath $path -Recurse -Force
}
function Rule { Write-Host ('  ' + ('-' * 60)) -ForegroundColor DarkGray }
function Step($text) { Write-Host ''; Write-Host ('  ' + $text) -ForegroundColor Cyan }
function Ok($text) { Write-Host ('  [OK] ' + $text) -ForegroundColor Green }
function Warn($text) { Write-Host ('  [!]  ' + $text) -ForegroundColor Yellow }
function Bad($text) { Write-Host ('  [X]  ' + $text) -ForegroundColor Red }

Write-Host ''
Write-Host '  壁纸引擎插件 · 安装' -ForegroundColor White
Rule
Write-Host '  把本机 Wallpaper Engine 的视频壁纸接进 DSH 当动态背景，'
Write-Host '  并把左侧栏和对话输入框做成毛玻璃（磨砂玻璃质感）。'
Rule

# ---------------------------------------------------------------- 1/5
Step '1/5  定位 DSH 主目录'

$dsh = $null
$tried = @()
foreach ($candidate in @($DshHome, $env:DSH_HOME, (Join-Path $env:USERPROFILE '.dsh'))) {
  if (-not $candidate) { continue }
  $tried += $candidate
  if (Test-Path -LiteralPath (Join-Path $candidate 'profiles')) {
    $dsh = (Resolve-Path -LiteralPath $candidate).Path
    break
  }
}
if (-not $dsh) {
  Warn '这几个位置都没有 profiles 文件夹：'
  foreach ($t in $tried) { Write-Host ('        ' + $t) }
  Write-Host ''
  Write-Host '  请手动输入 DSH 主目录（就是那个放着 profiles 的隐藏文件夹，'
  Write-Host '  一般形如 C:\Users\你的用户名\.dsh）：'
  $typed = Read-Host '  路径'
  if ($typed -and (Test-Path -LiteralPath (Join-Path $typed 'profiles'))) {
    $dsh = (Resolve-Path -LiteralPath $typed).Path
  }
}
if (-not $dsh) { Bad '没找到 DSH 主目录，安装中止。'; exit 1 }
Ok ('DSH 主目录 = ' + $dsh)

# ---------------------------------------------------------------- 2/5
Step '2/5  选择要装的 profile'

$candidates = @(
  Get-ChildItem -LiteralPath (Join-Path $dsh 'profiles') -Directory -ErrorAction SilentlyContinue |
    Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'package.json') }
)
if ($candidates.Count -eq 0) {
  Bad '这个 DSH 里没有可用的 profile。先用 DSH 正常启动一次，再回来装。'
  exit 1
}

$target = $null
if ($Profile) { $target = $candidates | Where-Object { $_.Name -eq $Profile } | Select-Object -First 1 }
if (-not $target) { $target = $candidates | Where-Object { $_.Name -eq 'web' } | Select-Object -First 1 }
if (-not $target -and $candidates.Count -eq 1) { $target = $candidates[0] }
if (-not $target) {
  Write-Host '  找到多个 profile，选一个装上：'
  for ($i = 0; $i -lt $candidates.Count; $i++) {
    Write-Host ('        [' + ($i + 1) + '] ' + $candidates[$i].Name)
  }
  $pick = Read-Host '  输入序号'
  $index = 0
  if ([int]::TryParse($pick, [ref]$index) -and $index -ge 1 -and $index -le $candidates.Count) {
    $target = $candidates[$index - 1]
  }
}
if (-not $target) { Bad '没有选中 profile，安装中止。'; exit 1 }
Ok ('profile = ' + $target.Name)

# ---------------------------------------------------------------- 3/5
Step '3/5  复制插件到 DSH 主目录'

$pluginsDir = Join-Path $dsh 'plugins'
$pluginDir = Join-Path $pluginsDir $PLUGIN
$rootsFile = Join-Path $pluginDir 'roots.json'
$rootsKeep = $null
if (Test-Path -LiteralPath $rootsFile) {
  $rootsKeep = [System.IO.File]::ReadAllText($rootsFile)
}
Remove-Tree $pluginDir
New-Item -ItemType Directory -Path $pluginDir -Force | Out-Null
foreach ($item in @('lib', 'package.json', 'cordis.patch.yml', 'README.md', 'profile-patch.mjs')) {
  Copy-Item -LiteralPath (Join-Path $here $item) -Destination $pluginDir -Recurse -Force
}
if ($rootsKeep) {
  [System.IO.File]::WriteAllText($rootsFile, $rootsKeep)
  Ok '保留了原来手写的 roots.json'
}
Ok ('插件目录 = ' + $pluginDir)

# ---------------------------------------------------------------- 4/5
Step '4/5  改 profile 的 package.json（改前自动备份）'

$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
  Bad '找不到 node 命令。DSH 本身就跑在 Node 上，把 node 加进 PATH 后重跑即可。'
  exit 1
}
& $node.Source (Join-Path $here 'profile-patch.mjs') 'add' $target.FullName $pluginDir
if ($LASTEXITCODE -ne 0) { Bad '修改 profile 配置失败。'; exit 1 }
Ok 'profile 配置已更新（同目录下留有 .bak-wallpaper-* 备份）'

# ---------------------------------------------------------------- 5/5
Step '5/5  放进 profile 的 node_modules'

$dest = Join-Path (Join-Path $target.FullName 'node_modules') $PLUGIN
Remove-Tree $dest
New-Item -ItemType Directory -Path $dest -Force | Out-Null
foreach ($item in @('lib', 'package.json', 'cordis.patch.yml', 'README.md')) {
  Copy-Item -LiteralPath (Join-Path $here $item) -Destination $dest -Recurse -Force
}
Ok ('已放入 ' + $dest)

# ---------------------------------------------------------------- 附带检查
Step '顺便看一下插件会去哪些目录找壁纸'

$found = @()
try {
  $raw = & $node.Source (Join-Path $here 'profile-patch.mjs') 'roots' $here 2>$null
  if ($raw) { $found = @($raw | ConvertFrom-Json) }
} catch {
  $found = @()
}
if ($found.Count -gt 0) {
  foreach ($path in $found) { Ok ('找到 ' + $path) }
} else {
  Warn '没探测到 Wallpaper Engine 目录。'
  Write-Host '        插件会自动扫描所有 Steam 库；如果你的 WE 装在很特别的位置，'
  Write-Host ('        可以手写 ' + $pluginDir + '\roots.json，例如：')
  Write-Host '          ["D:\\Steam\\steamapps\\workshop\\content\\431960"]'
}

# ---------------------------------------------------------------- 结果
Write-Host ''
Rule
Write-Host '  装好了，接下来：' -ForegroundColor White
Write-Host '    1. 完全退出 DSH，再重新启动（插件是启动时加载的）'
Write-Host '    2. 页面左下角会出现一个 🖼 按钮，点它打开设置面板'
Write-Host '       （也可以在地址后面加  #wallpaper-panel=1  直接打开）'
Write-Host '    3. 面板「壁纸」页挑一张 → 点「应用这张」'
Write-Host ''
Write-Host '  想卸载：双击同一个目录里的「卸载.cmd」。' -ForegroundColor White
Write-Host '  出问题先看 README.md —— 常见坑都记在里面了。' -ForegroundColor White
Rule
Write-Host ''
