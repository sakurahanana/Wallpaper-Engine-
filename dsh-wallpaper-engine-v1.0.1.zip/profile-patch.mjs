#!/usr/bin/env node
/**
 * 改 DSH profile 的 package.json —— 加上或移除本插件。
 *
 *   node profile-patch.mjs add    <profileDir> <pluginDir>
 *   node profile-patch.mjs remove <profileDir>
 *   node profile-patch.mjs roots  <pluginDir>
 *
 * 为什么用 Node 而不是 PowerShell 改 JSON：Windows PowerShell 5.1 的
 * ConvertTo-Json 会把嵌套结构压坏（-Depth 不够就丢层级），而 DSH 本来就
 * 跑在 Node 上，所以 node 一定在。改之前会在同目录写一份带时间戳的备份。
 */
import { copyFileSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const PLUGIN = "dsh-skin-wallpaper-engine";
const action = process.argv[2];
const arg1 = process.argv[3];
const arg2 = process.argv[4];

function fail(message) {
  console.error("  [X] " + message);
  process.exit(1);
}

/* ---- roots：把插件自己的目录探测结果打出来，安装时给用户看 ---- */
if (action === "roots") {
  if (!arg1) fail("usage: node profile-patch.mjs roots <pluginDir>");
  const entry = path.join(path.resolve(arg1), "lib", "index.js");
  if (!existsSync(entry)) fail("找不到 " + entry);
  const mod = await import("file://" + entry.replace(/\\/gu, "/"));
  const roots = mod.detectRoots();
  console.log(JSON.stringify(roots));
  process.exit(0);
}

if ((action !== "add" && action !== "remove") || !arg1) {
  fail("usage: node profile-patch.mjs add|remove <profileDir> [pluginDir]");
}
if (action === "add" && !arg2) fail("add 需要同时给出 <pluginDir>");

const file = path.join(path.resolve(arg1), "package.json");
if (!existsSync(file)) fail("找不到 " + file);

const json = JSON.parse(readFileSync(file, "utf8"));
const stamp = new Date().toISOString().replace(/[:.]/gu, "-");
const backup = file + ".bak-wallpaper-" + stamp;
copyFileSync(file, backup);

json.dependencies ??= {};
json.dsh ??= {};
json.dsh.profile ??= {};
json.dsh.profile.bundles ??= [];

if (action === "add") {
  json.dependencies[PLUGIN] = "file:" + path.resolve(arg2);
  if (!json.dsh.profile.bundles.includes(PLUGIN)) json.dsh.profile.bundles.push(PLUGIN);
  console.log("    已加入 dependencies 与 bundles");
} else {
  delete json.dependencies[PLUGIN];
  json.dsh.profile.bundles = json.dsh.profile.bundles.filter((name) => name !== PLUGIN);
  console.log("    已从 dependencies 与 bundles 移除");
}

writeFileSync(file, JSON.stringify(json, null, 4) + "\n", "utf8");
console.log("    写入 " + file);
console.log("    备份 " + path.basename(backup));
