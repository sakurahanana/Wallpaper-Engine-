﻿#Requires -Version 5.1
<#
  壁纸引擎插件 · 卸载
  ====================
    1. 定位 DSH 主目录（%DSH_HOME%，默认 %USERPROFILE%\.dsh）
    2. 把所有 profile 的 package.json 里关于本插件的条目清掉（改前自动备份）
    3. 删掉各 profile 的 node_modules 里的插件副本
    4. 删掉 <DSH_HOME>\plugins\dsh-skin-wallpaper-engine

  会扫所有 profile，所以装在哪个 profile 上都清得掉。
#>
[CmdletBinding()]
param(
  [string]$DshHome
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$PLUGIN = 'dsh-skin-wallpaper-engine'
$here = $PSScriptRoot

function Remove-Tree($path) {
  <#
    安全删除目录。关键：如果是 junction / 符号链接，只删链接本身。
    Windows PowerShell 5.1 的 Remove-Item -Recurse 会顺着重解析点把【目标】
    里的东西一起删掉 —— 而 DSH 的 link: 装法下那个目标就是插件的源码目录，
    删了就真没了。
  #>
  if (-not (Test-Path -LiteralPath $path)) { return }
  $item = Get-Item -LiteralPath $path -Force
  if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
    try {
      [System.IO.Directory]::Delete($path, $false)
    } catch {
      [void](cmd /c rmdir "$path" 2>&1)
    }
    return
  }
  Remove-Item -LiteralPath $path -Recurse -Force
}
function Rule { Write-Host ('  ' + ('-' * 60)) -ForegroundColor DarkGray }
function Step($text) { Write-Host ''; Write-Host ('  ' + $text) -ForegroundColor Cyan }
function Ok($text) { Write-Host ('  [OK] ' + $text) -ForegroundColor Green }
function Warn($text) { Write-Host ('  [!]  ' + $text) -ForegroundColor Yellow }
function Bad($text) { Write-Host ('  [X]  ' + $text) -ForegroundColor Red }

Write-Host ''
Write-Host '  壁纸引擎插件 · 卸载' -ForegroundColor White
Rule

# ---------------------------------------------------------------- 1/3
Step '1/3  定位 DSH 主目录'

$dsh = $null
foreach ($candidate in @($DshHome, $env:DSH_HOME, (Join-Path $env:USERPROFILE '.dsh'))) {
  if (-not $candidate) { continue }
  if (Test-Path -LiteralPath (Join-Path $candidate 'profiles')) {
    $dsh = (Resolve-Path -LiteralPath $candidate).Path
    break
  }
}
if (-not $dsh) {
  Write-Host '  请手动输入 DSH 主目录（放着 profiles 的那个文件夹，形如 C:\Users\你\.dsh）：'
  $typed = Read-Host '  路径'
  if ($typed -and (Test-Path -LiteralPath (Join-Path $typed 'profiles'))) {
    $dsh = (Resolve-Path -LiteralPath $typed).Path
  }
}
if (-not $dsh) { Bad '没找到 DSH 主目录，卸载中止。'; exit 1 }
Ok ('DSH 主目录 = ' + $dsh)

# ---------------------------------------------------------------- 2/3
Step '2/3  从各 profile 的配置和 node_modules 里清掉'

$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
  Bad '找不到 node 命令，无法安全修改 package.json。请把 node 加进 PATH 后重跑。'
  exit 1
}

$profiles = @(
  Get-ChildItem -LiteralPath (Join-Path $dsh 'profiles') -Directory -ErrorAction SilentlyContinue |
    Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'package.json') }
)
if ($profiles.Count -eq 0) {
  Warn '这个 DSH 里没有 profile，跳过配置清理。'
} else {
  foreach ($profile in $profiles) {
    $text = [System.IO.File]::ReadAllText((Join-Path $profile.FullName 'package.json'))
    $touched = $text.Contains($PLUGIN)

    if ($touched) {
      & $node.Source (Join-Path $here 'profile-patch.mjs') 'remove' $profile.FullName
      if ($LASTEXITCODE -ne 0) { Warn ($profile.Name + ' 的配置清理失败，请手动检查'); continue }
      Ok ($profile.Name + ' 的 package.json 已清理')
    } else {
      Write-Host ('        ' + $profile.Name + ' 未引用本插件，跳过')
    }

    $copy = Join-Path (Join-Path $profile.FullName 'node_modules') $PLUGIN
    if (Test-Path -LiteralPath $copy) {
      Remove-Tree $copy
      Ok ('删掉 node_modules\' + $PLUGIN)
    }
  }
}

# ---------------------------------------------------------------- 3/3
Step '3/3  删掉插件主目录'

$pluginDir = Join-Path (Join-Path $dsh 'plugins') $PLUGIN
if (Test-Path -LiteralPath $pluginDir) {
  Remove-Tree $pluginDir
  Ok ('已删 ' + $pluginDir)
} else {
  Write-Host ('        ' + $pluginDir + ' 不存在，跳过')
}

# ---------------------------------------------------------------- 结果
Write-Host ''
Rule
Write-Host '  卸载完成。完全退出 DSH 再重新启动即可。' -ForegroundColor White
Write-Host '  想装回来就再跑一次「安装.cmd」。' -ForegroundColor White
Rule
Write-Host ''
