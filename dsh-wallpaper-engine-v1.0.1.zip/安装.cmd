@echo off
setlocal
title Wallpaper Engine skin - install
set "PS1=%~dp0install.ps1"
if not exist "%PS1%" (
  echo.
  echo  [ERROR] install.ps1 not found next to this file.
  echo.
  pause
  exit /b 1
)
rem  ASCII only on purpose: cmd.exe parses batch files with the OEM code page,
rem  so non-ASCII bytes here would corrupt its line offsets.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%" %*
echo.
pause
endlocal
